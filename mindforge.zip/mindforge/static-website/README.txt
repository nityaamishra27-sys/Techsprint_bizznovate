FLAVOURS OF JAIL — STATIC WEBSITE

Open index.html in a modern web browser. This is a regular, self-contained website and does not require Docker, Node, or a backend. Keep the assets folder beside index.html.

Included: menu filters; cell session; add diners; assign personal items; split an item evenly across everyone at the table; itemized paise-accurate diner and master bills with illustrative tax; print/save bill; simulate successful or declined test-gateway payments; spin the reward wheel once after every diner with a bill share is paid; and a jail-themed manager dashboard with table roster, bill splits, local sales, menu pricing and visibility.

The dashboard includes a two-diner example: You have a Mint Release Cooler; Friend has a Warden's Cappuccino; one Contraband Cheesy Bread is shared. Each diner owes their own drink + half the bread + their own illustrative tax. Use this in Manager Dashboard → Overview → Load 2-Diner Split Example.

Everything stays in this browser. Orders are not transmitted and no money is charged. The dashboard is a local preview, not a secured admin console. Tax is illustrative, and rewards cannot be redeemed by a live POS. For public access, upload index.html, dashboard.html, and the assets folder together to any static host.
