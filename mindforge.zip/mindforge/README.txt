FLAVOURS OF JAIL — COMPLETE CODE

This single parent folder contains both project versions:

- full-stack-prototype: frontend and backend source, Docker setup, and startup files. Start with README.md and start-prototype.bat.
- static-website: ready-to-open browser website and its images. Open index.html; see README.txt.

The static website uses local browser storage. Payments and analytics are demo-only. The full-stack frontend dependencies are not bundled; install them using its package files and documented setup.
