@echo off
setlocal
cd /d "%~dp0"
echo Flavours of Jail - local prototype
where docker >nul 2>&1
if errorlevel 1 (
  echo Docker Desktop is required. Install and start Docker Desktop, then run this file again.
  pause
  exit /b 1
)
docker info >nul 2>&1
if errorlevel 1 (
  echo Docker Desktop is installed but is not running. Start Docker Desktop, wait until it is ready, then try again.
  pause
  exit /b 1
)
echo Building and starting the app. The first run may take a few minutes.
docker compose up --build -d
if errorlevel 1 (
  echo Startup failed. Check Docker Desktop, then run: docker compose logs
  pause
  exit /b 1
)
timeout /t 3 /nobreak >nul
start "Flavours of Jail" http://localhost:5173/
echo The prototype is running at http://localhost:5173/
echo To stop it, run: docker compose down
pause
