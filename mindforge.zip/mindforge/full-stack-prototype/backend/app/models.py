from datetime import datetime
from zoneinfo import ZoneInfo
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, JSON, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

def now_local(): return datetime.now(ZoneInfo("Asia/Kolkata"))

class Role(Base):
    __tablename__ = "roles"
    name: Mapped[str] = mapped_column(String(20), primary_key=True)
    description: Mapped[str] = mapped_column(String(120), default="")

class Manager(Base):
    __tablename__ = "managers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    manager_id: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(ForeignKey("roles.name"), default="MANAGER")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class Region(Base):
    __tablename__ = "regions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    state_code: Mapped[str] = mapped_column(String(8), default="MP")

class MenuItem(Base):
    __tablename__ = "menu_items"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(140))
    description: Mapped[str] = mapped_column(String(400), default="")
    category: Mapped[str] = mapped_column(String(50))
    veg: Mapped[bool] = mapped_column(Boolean, default=True)
    allergens: Mapped[list] = mapped_column(JSON, default=list)
    image: Mapped[str] = mapped_column(String(180), default="")
    available: Mapped[bool] = mapped_column(Boolean, default=True)
    region_tag: Mapped[str] = mapped_column(String(80), default="Central India")
    price_paise: Mapped[int] = mapped_column(Integer, default=0)
    cost_paise: Mapped[int] = mapped_column(Integer, default=0)
    margin_type: Mapped[str] = mapped_column(String(32), default="STANDARD_LOW_MARGIN")
    is_signature: Mapped[bool] = mapped_column(Boolean, default=False)
    popular: Mapped[bool] = mapped_column(Boolean, default=False)

class MenuTemplate(Base):
    __tablename__ = "menu_templates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    region: Mapped[str] = mapped_column(String(80))
    item_ids: Mapped[list] = mapped_column(JSON, default=list)

class TaxProfile(Base):
    __tablename__ = "tax_profiles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    region: Mapped[str] = mapped_column(String(80))
    rules: Mapped[list] = mapped_column(JSON, default=list)
    effective_from: Mapped[str] = mapped_column(String(10), default="2026-01-01")

class PriceSet(Base):
    __tablename__ = "price_sets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    region: Mapped[str] = mapped_column(String(80))
    overrides: Mapped[dict] = mapped_column(JSON, default=dict)

class BestsellerRecord(Base):
    __tablename__ = "bestseller_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dish_id: Mapped[str] = mapped_column(String(40), index=True)
    dish_name: Mapped[str] = mapped_column(String(140))
    units_sold: Mapped[int] = mapped_column(Integer)
    revenue_paise: Mapped[int] = mapped_column(Integer)
    branch_id: Mapped[str] = mapped_column(String(40), index=True)
    month: Mapped[str] = mapped_column(String(7), index=True)
    region: Mapped[str] = mapped_column(String(80), default="Central India")
    popular: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("dish_id", "branch_id", "month"),)

class Branch(Base):
    __tablename__ = "branches"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(140))
    address: Mapped[str] = mapped_column(String(300), default="")
    region: Mapped[str] = mapped_column(String(80))
    manager_id: Mapped[str] = mapped_column(ForeignKey("managers.manager_id"), default="MGR-0001")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    loyalty_radius_m: Mapped[int] = mapped_column(Integer, default=500)
    latest_version: Mapped[int] = mapped_column(Integer, default=0)

class ConfigVersion(Base):
    __tablename__ = "config_versions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default="PUBLISHED")
    published_by: Mapped[str] = mapped_column(String(30))
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_local)
    __table_args__ = (UniqueConstraint("branch_id", "version"),)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[str] = mapped_column(String(30), index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    branch_id: Mapped[str | None] = mapped_column(String(40), nullable=True, index=True)
    ip_address: Mapped[str] = mapped_column(String(64), default="unknown")
    before_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_local, index=True)

class Session(Base):
    __tablename__ = "cell_sessions"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    session_code: Mapped[str] = mapped_column(String(16), unique=True)
    type: Mapped[str] = mapped_column(String(24))
    table_id: Mapped[str] = mapped_column(String(40), default="CELL-04")
    branch_id: Mapped[str] = mapped_column(ForeignKey("branches.id"), default="IND-01")
    pickup_time: Mapped[str] = mapped_column(String(40), default="")
    host_id: Mapped[str] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_local)
    status: Mapped[str] = mapped_column(String(24), default="OPEN")
    stamp_issued: Mapped[bool] = mapped_column(Boolean, default=False)
    items: Mapped[list] = mapped_column(JSON, default=list)
    members: Mapped[list] = mapped_column(JSON, default=list)

class LoyaltyStamp(Base):
    __tablename__ = "loyalty_stamps"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[str] = mapped_column(String(80))
    session_id: Mapped[str] = mapped_column(ForeignKey("cell_sessions.id"))
    device_hash: Mapped[str] = mapped_column(String(64), index=True, default="")
    phone_hash: Mapped[str] = mapped_column(String(64), default="")
    ip_hash: Mapped[str] = mapped_column(String(64), default="")
    stamped_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_local)
    __table_args__ = (UniqueConstraint("session_id"),)

class LoyaltyAttempt(Base):
    __tablename__ = "loyalty_attempts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[str] = mapped_column(String(40), index=True)
    identity_hash: Mapped[str] = mapped_column(String(64))
    reason: Mapped[str] = mapped_column(String(100))
    attempted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_local)

