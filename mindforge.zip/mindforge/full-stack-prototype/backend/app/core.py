"""Integer-paise and access-control helpers shared by the API and unit tests."""

ROLES = {"SUPER_ADMIN", "MANAGER", "STAFF"}
LOCKOUT_ATTEMPTS = 5

def role_allowed(role: str, allowed: tuple[str, ...]) -> bool:
    return role in ROLES and role in allowed

def failed_login_state(current: int) -> tuple[int, bool]:
    attempts = current + 1
    return (0, True) if attempts >= LOCKOUT_ATTEMPTS else (attempts, False)

def next_config_version(latest: int) -> int:
    if latest < 0: raise ValueError("Version cannot be negative")
    return latest + 1

def split_with_host_remainder(total_paise: int, count: int) -> list[int]:
    if total_paise < 0 or count < 1: raise ValueError("Invalid amount or share count")
    pieces = [total_paise // count for _ in range(count)]
    pieces[0] += total_paise - sum(pieces)
    return pieces

def tax_from_basis_points(taxable_paise: int, rate_bps: int) -> int:
    if taxable_paise < 0 or rate_bps < 0: raise ValueError("Tax inputs cannot be negative")
    return (taxable_paise * rate_bps + 5000) // 10000

def allocate_pro_rata(total_paise: int, weights: dict[str, int], host_id: str) -> dict[str, int]:
    if total_paise < 0 or any(v < 0 for v in weights.values()): raise ValueError("Invalid allocation values")
    total_weight = sum(weights.values())
    if total_weight == 0: return {k: 0 for k in weights}
    out = {key: total_paise * value // total_weight for key, value in weights.items()}
    if host_id not in out: out[host_id] = 0
    out[host_id] += total_paise - sum(out.values())
    return out
