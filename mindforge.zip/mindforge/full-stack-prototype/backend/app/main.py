from __future__ import annotations
import csv, hashlib, io, json, os, secrets, time, math
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo
from typing import Any
from uuid import uuid4
from fastapi import Depends, FastAPI, HTTPException, Request, Response, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.responses import JSONResponse
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from sqlalchemy import select, desc
from sqlalchemy.orm import Session as DBSession
from .database import Base, engine, get_db, SessionLocal
from .models import Role, Manager, MenuItem, Branch, ConfigVersion, AuditLog, Session, LoyaltyStamp, TaxProfile, PriceSet, Region, BestsellerRecord
from .models import LoyaltyAttempt
from .core import role_allowed, failed_login_state, next_config_version, split_with_host_remainder, tax_from_basis_points, allocate_pro_rata
import socketio
import redis

SECRET = os.getenv("JWT_SECRET")
if not SECRET: raise RuntimeError("JWT_SECRET must be configured in the environment")
ACCESS_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "10"))
REFRESH_DAYS = int(os.getenv("REFRESH_TOKEN_DAYS", "7"))
pwd = CryptContext(schemes=["argon2"], deprecated="auto")
failed_by_ip: dict[str, list[float]] = {}
last_seen: dict[str, float] = {}
redis_client=redis.Redis.from_url(os.getenv("REDIS_URL","redis://localhost:6379/0"),decode_responses=True,socket_connect_timeout=0.3,socket_timeout=0.3)
sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins=[])
app = FastAPI(title="Flavours of Jail Branch & Cell API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True, allow_methods=["GET","POST","PUT","DELETE","OPTIONS"], allow_headers=["Authorization","Content-Type","X-CSRF-Token"])

@sio.event
async def connect(sid, environ, auth):
    return True

@sio.event
async def join_cell(sid, data):
    session_id=str((data or {}).get("session_id", ""))
    if session_id: await sio.enter_room(sid,session_id)

@app.middleware("http")
async def hardening(request: Request, call_next):
    if request.method in {"POST","PUT","PATCH","DELETE"} and request.cookies.get("access_token") and not request.headers.get("authorization", "").startswith("Bearer "):
        csrf_cookie=request.cookies.get("csrf_token", "")
        if not csrf_cookie or request.headers.get("x-csrf-token")!=csrf_cookie: return JSONResponse(status_code=403,content={"detail":"CSRF token validation failed"})
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' http://localhost:8000 ws://localhost:8000 ws://localhost:5173"
    return response

class LoginIn(BaseModel): manager_id: str; password: str
class MenuIn(BaseModel): id: str; name: str; description: str = ""; category: str; veg: bool = True; allergens: list[str] = []; image: str = ""; available: bool = True; region_tag: str = "Central India"; price_paise: int = Field(ge=0); cost_paise: int = Field(default=0, ge=0); margin_type: str = "STANDARD_LOW_MARGIN"; is_signature: bool = False; popular: bool = False
class TaxIn(BaseModel): name: str; region: str; rules: list[dict[str, Any]]; effective_from: str = "2026-01-01"
class PriceIn(BaseModel): name: str; region: str; overrides: dict[str, int] = {}
class BranchIn(BaseModel): id: str; name: str; address: str = ""; region: str; manager_id: str = "MGR-0001"; latitude: float | None = None; longitude: float | None = None; loyalty_radius_m: int = Field(default=500,ge=50,le=5000)
class BranchCloneIn(BaseModel): source_branch_id: str; id: str; name: str; address: str = ""
class ConfigImportIn(BaseModel): snapshot: dict[str, Any]
class PublishIn(BaseModel): menu_template: str = "Central India Menu"; tax_profile_id: int | None = None; price_set_id: int | None = None; otp: str | None = None
class SessionCreate(BaseModel): type: str; table_id: str = "CELL-04"; branch_id: str = "IND-01"; pickup_time: str = ""; host_name: str = "Host"
class JoinIn(BaseModel): session_id: str; user_name: str; device_fingerprint: str
class ClaimIn(BaseModel): session_id: str; item_id: str; share_type: str = "FULL"; split_count: int = Field(default=1,ge=1,le=50); quantity: int = Field(default=1,ge=1,le=50); member_ids: list[str] = []
class LinkIn(BaseModel): session_id: str; user_id: str; exact_share_amount: int = Field(ge=0)
class LoyaltyIn(BaseModel): session_id: str; phone_number: str; device_fingerprint: str; location_coords: list[float] = []

def audit(db: DBSession, actor: str, action: str, request: Request, before=None, after=None, branch=None):
    db.add(AuditLog(actor_id=actor, action=action, branch_id=branch, ip_address=(request.client.host if request.client else "unknown"), before_value=before, after_value=after)); db.commit()

def token_for(subject: str, role: str, kind: str, expires: timedelta):
    return jwt.encode({"sub": subject, "role": role, "kind": kind, "exp": datetime.now(timezone.utc)+expires}, SECRET, algorithm="HS256")

def current_user(request: Request, db: DBSession = Depends(get_db)):
    header = request.headers.get("authorization", "")
    token = header.removeprefix("Bearer ") if header.startswith("Bearer ") else request.cookies.get("access_token", "")
    if not token: raise HTTPException(401, "Sign in required")
    try: data = jwt.decode(token, SECRET, algorithms=["HS256"])
    except JWTError: raise HTTPException(401, "Session expired; sign in again")
    if data.get("kind") != "access": raise HTTPException(401, "Invalid access token")
    user = db.scalar(select(Manager).where(Manager.manager_id == data["sub"], Manager.active.is_(True)))
    if not user: raise HTTPException(401, "Account unavailable")
    now=time.time(); previous=last_seen.get(user.manager_id,now)
    if now-previous>15*60: last_seen.pop(user.manager_id,None); raise HTTPException(401,"Signed out after 15 minutes of inactivity")
    last_seen[user.manager_id]=now
    request.state.actor = user.manager_id
    return user

def roles(*allowed):
    def guard(user: Manager = Depends(current_user)):
        if not role_allowed(user.role, allowed): raise HTTPException(403, "This role cannot access the management console")
        return user
    return guard

def admin_or_manager(user=Depends(roles("SUPER_ADMIN", "MANAGER"))): return user
def privileged(user=Depends(roles("SUPER_ADMIN"))): return user

@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        if not db.scalar(select(Role).limit(1)):
            db.add_all([Role(name="SUPER_ADMIN",description="Provision accounts and manage the network"),Role(name="MANAGER",description="Manage assigned branches and configuration"),Role(name="STAFF",description="Restaurant staff; no dashboard access")]); db.commit()
        demo_manager_id=os.getenv("DEMO_MANAGER_ID", "MGR-0001"); demo_password=os.getenv("DEMO_MANAGER_PASSWORD")
        if not demo_password: raise RuntimeError("Set DEMO_MANAGER_PASSWORD before starting the prototype")
        if not db.scalar(select(Manager).where(Manager.manager_id == demo_manager_id)):
            db.add(Manager(manager_id=demo_manager_id, name="Demo Warden", password_hash=pwd.hash(demo_password), role="SUPER_ADMIN")); db.commit()
        if not db.scalar(select(Region).where(Region.name == "Central India")):
            db.add_all([Region(name="Central India", state_code="MP"), Region(name="South India", state_code="KA")]); db.commit()
        if not db.scalar(select(MenuItem).limit(1)):
            rows = [
            ("pizza-signature","Cell Block Paneer Pizza","Tandoor paneer, peppers and house spice","Signature Bundles",43900,16800,"signature-pizza.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("pizza-jailhouse","Jailhouse Special Pizza","A shareable, loaded house pizza","Signature Bundles",49900,18200,"cell-pizza.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("pasta","Creamy Convict Pasta","Creamy penne with peppers and herbs","Mains",32900,17800,"creamy-pasta.jpg","STANDARD_LOW_MARGIN",False),
            ("cheesy-bread","Contraband Cheesy Bread","Toasted cheesy bread for the table","Shared Rations",21900,7600,"cheesy-bread.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("loaded-fries","Loaded Cell Fries","Crispy fries with cheese and house sauce","Shared Rations",18900,6900,"loaded-fries.jpg","STANDARD_LOW_MARGIN",False),
            ("mocktail","Jailhouse Mocktail Flight","Bright house mocktails, made for sharing","Drinks",29900,7200,"jailhouse-mocktails.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("mint-cooler","Mint Release Cooler","Fresh mint and lime cooler","Drinks",14900,4200,"mint-cooler.jpg","STANDARD_LOW_MARGIN",False),
            ("coffee","Warden's Cappuccino","Espresso with silky steamed milk","Drinks",15900,3900,"cappuccino.jpg","SIGNATURE_HIGH_MARGIN",False),
            ("cheesecake","Bail Release Cheesecake","Caramel cheesecake with cream","Desserts",19900,6200,"cheesecake.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("chocolate-dessert","Midnight Chocolate Pudding","Chocolate pudding with white chocolate","Desserts",18900,5500,"chocolate-dessert.jpg","STANDARD_LOW_MARGIN",False),
            ("veg-supreme","Escape Route Veg Supreme","Garden vegetables, olives and smoked cheese","Mains",37900,14500,"signature-pizza.jpg","STANDARD_LOW_MARGIN",False),
            ("pepper-paneer","Pepper Paneer Cell Pizza","Paneer, peppers and a black pepper crust","Mains",39900,15100,"cell-pizza.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("garlic-bread","Warden's Garlic Toast","Toasted garlic loaf with herbs","Shared Rations",16900,5100,"cheesy-bread.jpg","STANDARD_LOW_MARGIN",False),
            ("masala-fries","Masala Contraband Fries","Spiced fries with fresh herbs","Shared Rations",15900,4900,"loaded-fries.jpg","STANDARD_LOW_MARGIN",False),
            ("blue-mocktail","Blue Cell Cooler","Citrus, mint and a blue sparkle","Drinks",17900,4700,"jailhouse-mocktails.jpg","SIGNATURE_HIGH_MARGIN",False),
            ("lime-soda","Fresh Lime Release","Lime soda, sweet or salted","Drinks",9900,2500,"mint-cooler.jpg","STANDARD_LOW_MARGIN",False),
            ("espresso","Double Lock Espresso","A short, intense double espresso","Drinks",12900,3100,"cappuccino.jpg","SIGNATURE_HIGH_MARGIN",False),
            ("caramel-cake","Caramel Case Cake","Creamy caramel cheesecake slice","Desserts",20900,6700,"cheesecake.jpg","SIGNATURE_HIGH_MARGIN",True),
            ("brownie","Dark Cell Brownie","Warm chocolate brownie with a soft centre","Desserts",17900,5400,"chocolate-dessert.jpg","STANDARD_LOW_MARGIN",False),
            ("pasta-pesto","Pesto Parole Pasta","Herb pesto pasta with toasted bread","Mains",34900,16100,"creamy-pasta.jpg","STANDARD_LOW_MARGIN",False)]
            db.add_all([MenuItem(id=i,name=n,description=d,category=c,price_paise=p,cost_paise=cost,image=im,margin_type=m,is_signature=s) for i,n,d,c,p,cost,im,m,s in rows]); db.commit()
        if not db.scalar(select(TaxProfile).limit(1)):
            db.add_all([TaxProfile(name="Indore Dine-in",region="Central India",rules=[{"name":"CGST","rate_bps":250,"applies_to":"all","inclusive":False},{"name":"SGST","rate_bps":250,"applies_to":"all","inclusive":False}]),TaxProfile(name="Bengaluru Dine-in",region="South India",rules=[{"name":"CGST","rate_bps":250,"applies_to":"all","inclusive":False},{"name":"SGST","rate_bps":250,"applies_to":"all","inclusive":False}])]); db.commit()
        if not db.scalar(select(Branch).limit(1)):
            db.add_all([Branch(id="IND-01",name="Indore · Vijay Nagar",address="Scheme 54, Indore",region="Central India",latitude=22.7533,longitude=75.8937),Branch(id="BPL-02",name="Bhopal · Arera Colony",address="E-5 Arera Colony, Bhopal",region="Central India",latitude=23.2124,longitude=77.4341),Branch(id="BLR-03",name="Bengaluru · Indiranagar",address="100 Feet Road, Bengaluru",region="South India",latitude=12.9784,longitude=77.6408)]); db.commit()
        for branch in db.scalars(select(Branch)).all():
            if branch.latest_version==0:
                version=next_config_version(branch.latest_version); snapshot=snapshot_for(db,branch)
                db.add(ConfigVersion(branch_id=branch.id,version=version,snapshot=snapshot,status="PUBLISHED",published_by=demo_manager_id)); branch.latest_version=version
        db.commit()
    finally: db.close()

@app.post("/auth/login")
def login(body: LoginIn, request: Request, response: Response, db: DBSession = Depends(get_db)):
    ip = request.client.host if request.client else "unknown"; hits = [t for t in failed_by_ip.get(ip, []) if time.time()-t < 60]
    try:
        rate_count=redis_client.incr(f"login-rate:{ip}")
        if rate_count==1: redis_client.expire(f"login-rate:{ip}",60)
    except redis.RedisError:
        rate_count=len(hits)
    if rate_count >= 20: raise HTTPException(429, "Too many attempts. Try again shortly.")
    user = db.scalar(select(Manager).where(Manager.manager_id == body.manager_id))
    lock_until=user.locked_until if user else None
    if lock_until and lock_until.tzinfo is None: lock_until=lock_until.replace(tzinfo=timezone.utc)
    if not user or not user.active or (lock_until and lock_until > datetime.now(timezone.utc)) or not pwd.verify(body.password, user.password_hash if user else pwd.hash("invalid")):
        failed_by_ip[ip] = hits+[time.time()]
        if user:
            user.failed_attempts,locked=failed_login_state(user.failed_attempts)
            if locked: user.locked_until = datetime.now(timezone.utc)+timedelta(minutes=15)
            db.commit()
        raise HTTPException(401, "Invalid manager ID or password")
    user.failed_attempts=0; user.locked_until=None; db.commit()
    access=token_for(user.manager_id,user.role,"access",timedelta(minutes=ACCESS_MINUTES)); refresh=token_for(user.manager_id,user.role,"refresh",timedelta(days=REFRESH_DAYS))
    response.set_cookie("refresh_token",refresh,httponly=True,secure=os.getenv("COOKIE_SECURE","false").lower()=="true",samesite="strict",max_age=REFRESH_DAYS*86400,path="/auth")
    response.set_cookie("access_token",access,httponly=True,secure=os.getenv("COOKIE_SECURE","false").lower()=="true",samesite="strict",max_age=ACCESS_MINUTES*60)
    response.set_cookie("csrf_token",secrets.token_urlsafe(24),httponly=False,secure=os.getenv("COOKIE_SECURE","false").lower()=="true",samesite="strict",max_age=REFRESH_DAYS*86400)
    last_seen[user.manager_id]=time.time()
    return {"access_token":access,"token_type":"bearer","role":user.role,"manager_id":user.manager_id,"name":user.name}

@app.post("/auth/refresh")
def refresh(request: Request, response: Response):
    try: data=jwt.decode(request.cookies.get("refresh_token", ""),SECRET,algorithms=["HS256"])
    except JWTError: raise HTTPException(401,"Refresh session expired")
    if data.get("kind")!="refresh": raise HTTPException(401,"Invalid refresh token")
    if time.time()-last_seen.get(data["sub"],0)>15*60: raise HTTPException(401,"Signed out after 15 minutes of inactivity")
    access=token_for(data["sub"],data["role"],"access",timedelta(minutes=ACCESS_MINUTES)); response.set_cookie("access_token",access,httponly=True,samesite="strict",max_age=ACCESS_MINUTES*60); return {"access_token":access}

@app.post("/auth/logout")
def logout(response: Response): response.delete_cookie("access_token"); response.delete_cookie("refresh_token",path="/auth"); response.delete_cookie("csrf_token"); return {"ok":True}

@app.get("/auth/me")
def me(user: Manager=Depends(current_user)): return {"manager_id":user.manager_id,"name":user.name,"role":user.role}

@app.get("/menu-items")
def menu_items(_: Manager=Depends(admin_or_manager), db:DBSession=Depends(get_db)):
    return [{**{k:getattr(x,k) for k in ("id","name","description","category","veg","allergens","image","available","region_tag","price_paise","cost_paise","margin_type","is_signature","popular")},"price":f"₹{x.price_paise/100:.2f}"} for x in db.scalars(select(MenuItem)).all()]

@app.post("/menu-items")
def create_menu(body:MenuIn, request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    if db.get(MenuItem,body.id): raise HTTPException(409,"Item id already exists")
    item=MenuItem(**body.model_dump()); db.add(item); db.commit(); audit(db,user.manager_id,"menu_item.created",request,after=body.model_dump()); return {"id":item.id,"ok":True}

@app.get("/menu-items/export")
def export_menu(format:str="json",_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    rows=[{k:getattr(x,k) for k in ("id","name","description","category","veg","allergens","image","available","region_tag","price_paise","cost_paise","margin_type","is_signature","popular")} for x in db.scalars(select(MenuItem)).all()]
    if format.lower()=="csv":
        buf=io.StringIO(); fields=list(rows[0]) if rows else ["id","name","category","price_paise"]; w=csv.DictWriter(buf,fieldnames=fields); w.writeheader(); w.writerows(rows); return StreamingResponse(iter([buf.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=regional-menu.csv"})
    return rows

@app.post("/menu-items/import")
async def import_menu(request:Request,file:UploadFile=File(...),user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    raw=await file.read(); errors=[]; accepted=[]
    try:
        decoded=raw.decode("utf-8-sig")
        records=json.loads(decoded) if file.filename and file.filename.lower().endswith(".json") else list(csv.DictReader(io.StringIO(decoded)))
        for idx,row in enumerate(records,start=1):
            try:
                data=MenuIn.model_validate(row).model_dump()
                if db.get(MenuItem,data["id"]): raise ValueError("menu item ID already exists")
                accepted.append(MenuItem(**data))
            except Exception as exc: errors.append({"row":idx,"error":str(exc)})
    except Exception: raise HTTPException(422,"Upload a valid CSV or JSON menu package")
    db.add_all(accepted); db.commit()
    audit(db,user.manager_id,"menu.imported",request,after={"accepted":len(accepted),"rejected":len(errors)})
    return {"accepted":len(accepted),"errors":errors}

@app.post("/auth/managers")
def provision_manager(body:dict,request:Request,user:Manager=Depends(privileged),db:DBSession=Depends(get_db)):
    manager_id=str(body.get("manager_id", "")).strip(); password=str(body.get("password", "")); name=str(body.get("name", "")).strip(); role=str(body.get("role", "MANAGER"))
    if not manager_id.startswith("MGR-") or len(password)<12 or not name or role not in ("MANAGER","STAFF","SUPER_ADMIN"):
        raise HTTPException(422,"Provide a provisioned MGR- ID, name, role and password of at least 12 characters")
    if db.scalar(select(Manager).where(Manager.manager_id==manager_id)): raise HTTPException(409,"Manager ID already exists")
    x=Manager(manager_id=manager_id,name=name,role=role,password_hash=pwd.hash(password)); db.add(x); db.commit(); audit(db,user.manager_id,"manager.provisioned",request,after={"manager_id":manager_id,"name":name,"role":role}); return {"manager_id":x.manager_id,"role":x.role}

@app.put("/menu-items/{item_id}")
def update_menu(item_id:str,body:MenuIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    item=db.get(MenuItem,item_id)
    if not item: raise HTTPException(404,"Menu item not found")
    before={k:getattr(item,k) for k in ("name","description","category","price_paise","cost_paise","available","margin_type","is_signature","popular")}
    for k,v in body.model_dump().items(): setattr(item,k,v)
    db.commit(); audit(db,user.manager_id,"menu_item.updated",request,before,body.model_dump()); return {"ok":True}

@app.get("/tax-profiles")
def taxes(_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)): return [{"id":x.id,"name":x.name,"region":x.region,"rules":x.rules,"effective_from":x.effective_from} for x in db.scalars(select(TaxProfile)).all()]
@app.post("/tax-profiles")
def create_tax(body:TaxIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    t=TaxProfile(**body.model_dump()); db.add(t); db.commit(); audit(db,user.manager_id,"tax_profile.created",request,after=body.model_dump()); return {"id":t.id,"ok":True}

@app.get("/pricing")
def pricing(_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)): return [{"id":x.id,"name":x.name,"region":x.region,"overrides":x.overrides} for x in db.scalars(select(PriceSet)).all()]
@app.post("/pricing")
def create_pricing(body:PriceIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    if any(v<0 for v in body.overrides.values()): raise HTTPException(422,"Prices cannot be negative")
    x=PriceSet(**body.model_dump()); db.add(x); db.commit(); audit(db,user.manager_id,"price_set.created",request,after=body.model_dump()); return {"id":x.id,"ok":True}

@app.get("/branches")
def branches(_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    return [{"id":x.id,"name":x.name,"address":x.address,"region":x.region,"manager_id":x.manager_id,"latitude":x.latitude,"longitude":x.longitude,"loyalty_radius_m":x.loyalty_radius_m,"version":x.latest_version,"state":"LIVE" if x.latest_version>0 else "REVIEW"} for x in db.scalars(select(Branch)).all()]
@app.post("/branches")
def create_branch(body:BranchIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    if db.get(Branch,body.id): raise HTTPException(409,"Branch id exists")
    if not db.scalar(select(Manager).where(Manager.manager_id==body.manager_id,Manager.active.is_(True))): raise HTTPException(422,"Assigned branch manager does not exist or is inactive")
    x=Branch(**body.model_dump()); db.add(x); db.commit(); audit(db,user.manager_id,"branch.created",request,after=body.model_dump(),branch=x.id); return {"id":x.id,"ok":True}

@app.post("/branches/clone")
def clone_branch(body:BranchCloneIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    source=db.get(Branch,body.source_branch_id)
    if not source: raise HTTPException(404,"Source branch not found")
    if db.get(Branch,body.id): raise HTTPException(409,"Branch id already exists")
    dest=Branch(id=body.id,name=body.name,address=body.address,region=source.region,manager_id=user.manager_id,latitude=source.latitude,longitude=source.longitude,loyalty_radius_m=source.loyalty_radius_m,latest_version=0); db.add(dest); db.commit()
    previous=db.scalar(select(ConfigVersion).where(ConfigVersion.branch_id==source.id).order_by(desc(ConfigVersion.version)))
    if previous:
        snap={**previous.snapshot,"branch":{"id":dest.id,"name":dest.name,"region":dest.region}}
        row=ConfigVersion(branch_id=dest.id,version=1,snapshot=snap,status="PUBLISHED",published_by=user.manager_id); db.add(row); dest.latest_version=1; db.commit()
    audit(db,user.manager_id,"branch.cloned",request,after={"source":source.id,"branch":dest.id},branch=dest.id); return {"id":dest.id,"version":dest.latest_version}

def snapshot_for(db, branch, tax_id=None, price_id=None):
    items=db.scalars(select(MenuItem)).all(); prices={}
    if price_id:
        ps=db.get(PriceSet,price_id)
        if ps: prices=ps.overrides
    tax=db.get(TaxProfile,tax_id) if tax_id else db.scalar(select(TaxProfile).where(TaxProfile.region==branch.region))
    return {"branch":{"id":branch.id,"name":branch.name,"region":branch.region},"menu":[{"id":x.id,"name":x.name,"description":x.description,"category":x.category,"veg":x.veg,"allergens":x.allergens,"image":x.image,"price_paise":prices.get(x.id,x.price_paise),"available":x.available,"popular":x.popular,"is_signature":x.is_signature} for x in items],"taxes":tax.rules if tax else [],"tax_profile":tax.name if tax else None,"published_at":datetime.now(timezone.utc).isoformat()}

@app.post("/branches/{branch_id}/deploy")
def deploy(branch_id:str,body:PublishIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    if os.getenv("REQUIRE_DEPLOY_OTP","false").lower()=="true" and body.otp!=os.getenv("DEPLOY_OTP"):
        raise HTTPException(401,"A valid second-factor code is required to publish")
    branch=db.get(Branch,branch_id)
    if not branch: raise HTTPException(404,"Branch not found")
    version=next_config_version(branch.latest_version); snap=snapshot_for(db,branch,body.tax_profile_id,body.price_set_id)
    v=ConfigVersion(branch_id=branch.id,version=version,snapshot=snap,published_by=user.manager_id,status="PUBLISHED"); db.add(v); branch.latest_version=version; db.commit(); audit(db,user.manager_id,"branch.deployed",request,after={"version":version,"snapshot":snap},branch=branch_id)
    return {"status":"PUBLISHED","version":version,"published_at":v.published_at.isoformat()}

@app.get("/branches/{branch_id}/config/export")
def export_config(branch_id:str,format:str="json",user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    v=db.scalar(select(ConfigVersion).where(ConfigVersion.branch_id==branch_id).order_by(desc(ConfigVersion.version)))
    if not v: raise HTTPException(404,"No published configuration")
    if format=="csv":
        buf=io.StringIO(); w=csv.DictWriter(buf,fieldnames=["id","name","category","price_paise","available","popular"]); w.writeheader(); w.writerows(v.snapshot["menu"]); return StreamingResponse(iter([buf.getvalue()]),media_type="text/csv",headers={"Content-Disposition":f"attachment; filename={branch_id}-config.csv"})
    return v.snapshot

@app.post("/branches/{branch_id}/config/import")
def import_config(branch_id:str,body:ConfigImportIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    branch=db.get(Branch,branch_id)
    if not branch: raise HTTPException(404,"Branch not found")
    snap=body.snapshot
    if not isinstance(snap.get("menu"),list) or not isinstance(snap.get("taxes"),list): raise HTTPException(422,"Package must include menu and taxes")
    snap={**snap,"branch":{"id":branch.id,"name":branch.name,"region":branch.region},"published_at":datetime.now(timezone.utc).isoformat()}
    version=next_config_version(branch.latest_version); row=ConfigVersion(branch_id=branch.id,version=version,snapshot=snap,status="PUBLISHED",published_by=user.manager_id); db.add(row); branch.latest_version=version; db.commit(); audit(db,user.manager_id,"branch.config_imported",request,after={"version":version},branch=branch.id); return {"version":version,"status":"PUBLISHED"}

@app.post("/branches/{branch_id}/rollback")
def rollback(branch_id:str,version:int,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    branch=db.get(Branch,branch_id); old=db.scalar(select(ConfigVersion).where(ConfigVersion.branch_id==branch_id,ConfigVersion.version==version))
    if not branch or not old: raise HTTPException(404,"Branch or version not found")
    nxt=next_config_version(branch.latest_version); v=ConfigVersion(branch_id=branch_id,version=nxt,snapshot=old.snapshot,status="PUBLISHED",published_by=user.manager_id); db.add(v); branch.latest_version=nxt; db.commit(); audit(db,user.manager_id,"branch.rollback",request,before={"version":version},after={"version":nxt},branch=branch_id); return {"version":nxt,"rolled_back_to":version}

@app.get("/public/branches/{branch_id}/config")
def public_config(branch_id:str,db:DBSession=Depends(get_db)):
    v=db.scalar(select(ConfigVersion).where(ConfigVersion.branch_id==branch_id,ConfigVersion.status=="PUBLISHED").order_by(desc(ConfigVersion.version)))
    if not v: raise HTTPException(404,"No published branch config")
    return v.snapshot

@app.get("/audit-logs")
def audit_logs(manager:str|None=None,branch_id:str|None=None,action:str|None=None,from_date:datetime|None=None,to_date:datetime|None=None,limit:int=50,_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    q=select(AuditLog).order_by(desc(AuditLog.created_at)).limit(min(max(limit,1),200))
    if manager:q=q.where(AuditLog.actor_id==manager)
    if branch_id:q=q.where(AuditLog.branch_id==branch_id)
    if action:q=q.where(AuditLog.action.contains(action))
    if from_date:q=q.where(AuditLog.created_at>=from_date)
    if to_date:q=q.where(AuditLog.created_at<=to_date)
    return [{"id":x.id,"manager":x.actor_id,"action":x.action,"branch_id":x.branch_id,"ip":x.ip_address,"before":x.before_value,"after":x.after_value,"at":x.created_at.isoformat()} for x in db.scalars(q).all()]

@app.post("/bestsellers/import")
async def import_bestsellers(request:Request,file:UploadFile=File(...),user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    data=await file.read(); errors=[]; valid=[]; seen=set()
    try:
        for n,row in enumerate(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))),start=2):
            try:
                if not all(row.get(k) for k in ("dish_id","dish_name","units_sold","revenue","branch_id","month")): raise ValueError("required field missing")
                units=int(row["units_sold"]); revenue=Decimal(row["revenue"]); key=(row["dish_id"],row["branch_id"],row["month"])
                if units<0 or revenue<0: raise ValueError("sales cannot be negative")
                if key in seen or db.scalar(select(BestsellerRecord).where(BestsellerRecord.dish_id==key[0],BestsellerRecord.branch_id==key[1],BestsellerRecord.month==key[2])): raise ValueError("duplicate dish, branch and month record")
                seen.add(key); valid.append({"dish_id":row["dish_id"],"dish_name":row["dish_name"],"units_sold":units,"revenue_paise":int(revenue*100),"branch_id":row["branch_id"],"month":row["month"]})
            except Exception as e: errors.append({"row":n,"error":str(e)})
    except Exception: raise HTTPException(422,"Upload a valid CSV file")
    for row in valid:
        branch=db.get(Branch,row["branch_id"]); region=branch.region if branch else "Central India"
        db.add(BestsellerRecord(**row,region=region))
    db.commit()
    audit(db,user.manager_id,"bestsellers.imported",request,after={"rows_accepted":len(valid),"rows_rejected":len(errors)})
    return {"accepted":valid,"errors":errors}
@app.get("/bestsellers/top")
def bestseller_top(region:str|None=None,month:str|None=None,n:int=5,_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    q=select(BestsellerRecord)
    if region:q=q.where(BestsellerRecord.region==region)
    if month:q=q.where(BestsellerRecord.month==month)
    rows=db.scalars(q).all(); grouped={}
    for x in rows:
        item=grouped.setdefault(x.dish_id,{"dish_id":x.dish_id,"dish_name":x.dish_name,"units_sold":0,"revenue_paise":0,"popular":False,"region":x.region,"month":x.month})
        item["units_sold"]+=x.units_sold; item["revenue_paise"]+=x.revenue_paise; item["popular"]|=x.popular
    return sorted(grouped.values(),key=lambda x:x["units_sold"],reverse=True)[:max(1,min(n,100))]

class PopularIn(BaseModel): dish_ids:list[str]; popular:bool=True
@app.post("/bestsellers/popular")
def mark_popular(body:PopularIn,request:Request,user:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    changed=[]
    for dish_id in body.dish_ids:
        item=db.get(MenuItem,dish_id)
        if item:item.popular=body.popular; changed.append(dish_id)
        for record in db.scalars(select(BestsellerRecord).where(BestsellerRecord.dish_id==dish_id)).all(): record.popular=body.popular
    db.commit(); audit(db,user.manager_id,"bestsellers.popular_updated",request,after={"dish_ids":changed,"popular":body.popular}); return {"updated":changed}

def split_paise(total:int,count:int): return split_with_host_remainder(total,count)
def share_breakdown(session:Session,db:DBSession):
    members=session.members or [{"id":session.host_id,"name":"Host"}]; member_ids=[m["id"] for m in members]; subtotal={uid:0 for uid in member_ids}; by_category={uid:{} for uid in member_ids}; host=session.host_id
    for line in session.items or []:
        price=int(line["price_paise"])*int(line.get("quantity",1)); owners=line.get("owners",[]); category=line.get("category","all")
        if not owners: continue
        pieces=split_paise(price,len(owners))
        for uid,p in zip(owners,pieces):
            subtotal[uid]=subtotal.get(uid,0)+p; by_category.setdefault(uid,{})[category]=by_category.setdefault(uid,{}).get(category,0)+p
    total=sum(subtotal.values()); tax_by_member={uid:0 for uid in member_ids}; included_tax_by_member={uid:0 for uid in member_ids}; rules=[]
    profile=db.scalar(select(TaxProfile).order_by(TaxProfile.id))
    if profile: rules=profile.rules
    for rule in rules:
        category=rule.get("applies_to","all"); eligible={uid:(sum(by_category[uid].values()) if category in ("all",None) else by_category[uid].get(category,0)) for uid in member_ids}; taxable=sum(eligible.values()); rate=int(rule.get("rate_bps",0))
        if taxable<=0 or rate<=0: continue
        tax_total=tax_from_basis_points(taxable,rate); allocated=allocate_pro_rata(tax_total,eligible,host)
        target=included_tax_by_member if rule.get("inclusive",False) else tax_by_member
        for uid,amount in allocated.items(): target[uid]=target.get(uid,0)+amount
    taxes=sum(tax_by_member.values())+sum(included_tax_by_member.values()); rows=[]
    for m in members:
        uid=m["id"]; rows.append({"user_id":uid,"name":m["name"],"subtotal_paise":subtotal.get(uid,0),"tax_paise":tax_by_member.get(uid,0)+included_tax_by_member.get(uid,0),"included_tax_paise":included_tax_by_member.get(uid,0),"total_paise":subtotal.get(uid,0)+tax_by_member.get(uid,0)})
    exclusive=sum(tax_by_member.values())
    return {"members":rows,"master_subtotal_paise":total,"tax_total_paise":taxes,"included_tax_paise":sum(included_tax_by_member.values()),"master_total_paise":total+exclusive,"balance_paise":sum(x["total_paise"] for x in rows)-(total+exclusive)}

@app.post("/api/v1/sessions/create")
async def session_create(body:SessionCreate,request:Request,db:DBSession=Depends(get_db)):
    if body.type not in ("DINE_IN","TAKEAWAY_PICKUP"): raise HTTPException(422,"type must be DINE_IN or TAKEAWAY_PICKUP")
    if not db.get(Branch,body.branch_id): raise HTTPException(404,"Outlet branch not found")
    sid=str(uuid4()); code=secrets.token_hex(3).upper(); row=Session(id=sid,session_code=code,type=body.type,table_id=body.table_id,branch_id=body.branch_id,pickup_time=body.pickup_time,host_id="host-"+sid[:8],members=[{"id":"host-"+sid[:8],"name":body.host_name,"device_fingerprint":"host-device"}]); db.add(row); db.commit()
    await sio.emit("cell_updated",{"event":"created","session_id":sid},room=sid)
    return {"session_id":sid,"shareable_link":f"{os.getenv('PUBLIC_APP_URL','http://localhost:5173')}/cell/{sid}","session_code":code,"host_id":row.host_id,"members":row.members}
@app.post("/api/v1/sessions/join")
async def session_join(body:JoinIn,request:Request,db:DBSession=Depends(get_db)):
    s=db.get(Session,body.session_id)
    if not s: raise HTTPException(404,"Cell session not found")
    if s.status!="OPEN": raise HTTPException(409,"This cell is no longer accepting new inmates")
    if any(m.get("device_fingerprint")==body.device_fingerprint for m in s.members): raise HTTPException(409,"This device already joined the cell")
    uid="inmate-"+str(uuid4())[:8]; s.members=[*s.members,{"id":uid,"name":body.user_name,"device_fingerprint":body.device_fingerprint}]; db.commit(); await sio.emit("cell_updated",{"event":"joined","members":s.members},room=s.id); return {"user_id":uid,"members":s.members}
@app.get("/api/v1/sessions/{session_id}")
def session_detail(session_id:str,db:DBSession=Depends(get_db)):
    s=db.get(Session,session_id)
    if not s: raise HTTPException(404,"Cell session not found")
    branch=db.get(Branch,s.branch_id)
    return {"session_id":s.id,"session_code":s.session_code,"type":s.type,"table_id":s.table_id,"branch_id":s.branch_id,"branch_name":branch.name if branch else "Restaurant","pickup_time":s.pickup_time,"status":s.status,"members":[{"id":m["id"],"name":m["name"]} for m in (s.members or [])],"items":[{"name":x["name"],"quantity":x.get("quantity",1),"share_type":x.get("share_type"),"price_paise":x["price_paise"]} for x in (s.items or [])]}
@app.get("/api/v1/menu/items")
def diner_menu(db:DBSession=Depends(get_db)):
    items=db.scalars(select(MenuItem).where(MenuItem.available.is_(True))).all()
    return {"items":[{"id":x.id,"name":x.name,"price_paise":x.price_paise,"category":x.category,"image":x.image,"is_signature":x.is_signature,"margin_type":x.margin_type,"popular":x.popular} for x in items],"bundle_suggestions":[{"name":"Solitary Confinement Meal Combo","description":"Pair a signature pizza with a drink and shared cheesy bread."}]}
@app.post("/api/v1/bills/claim-item")
async def claim_item(body:ClaimIn,db:DBSession=Depends(get_db)):
    s=db.get(Session,body.session_id); item=db.get(MenuItem,body.item_id)
    if not s or not item: raise HTTPException(404,"Session or ration not found")
    if s.status!="OPEN": raise HTTPException(409,"Shares are locked; reopen the bill before changing rations")
    if body.share_type not in ("FULL","SPLIT") or body.split_count<1: raise HTTPException(422,"Invalid share type or split count")
    members_by_id={m["id"] for m in s.members}; owners=body.member_ids or ([m["id"] for m in s.members[:body.split_count]] if body.share_type=="SPLIT" else [s.host_id])
    if len(owners)!=len(set(owners)): raise HTTPException(422,"A diner can only be counted once in a split")
    if any(uid not in members_by_id for uid in owners): raise HTTPException(422,"Claims must use members of this session")
    if body.share_type=="SPLIT" and len(owners)<2: raise HTTPException(422,"Shared items need at least two diners")
    if body.share_type=="FULL" and len(owners)!=1: raise HTTPException(422,"Personal items belong to one diner")
    s.items=[*s.items,{"id":str(uuid4()),"item_id":item.id,"name":item.name,"category":item.category,"price_paise":item.price_paise,"quantity":body.quantity,"share_type":body.share_type,"split_count":body.split_count,"owners":owners}]; db.commit(); await sio.emit("cell_updated",{"event":"ration_claimed","item":item.name},room=s.id); return share_breakdown(s,db)
@app.get("/api/v1/bills/reconcile/{session_id}")
def reconcile(session_id:str,db:DBSession=Depends(get_db)):
    s=db.get(Session,session_id)
    if not s: raise HTTPException(404,"Session not found")
    return share_breakdown(s,db)
@app.post("/api/v1/bills/lock/{session_id}")
async def lock_share(session_id:str,db:DBSession=Depends(get_db)):
    s=db.get(Session,session_id)
    if not s: raise HTTPException(404,"Session not found")
    s.status="LOCKED"; db.commit(); result=share_breakdown(s,db); await sio.emit("cell_updated",{"event":"shares_locked"},room=s.id); return result
@app.post("/api/v1/bills/reopen/{session_id}")
async def reopen_share(session_id:str,db:DBSession=Depends(get_db)):
    s=db.get(Session,session_id)
    if not s: raise HTTPException(404,"Session not found")
    if s.status!="LOCKED": raise HTTPException(409,"Share is not locked")
    s.status="OPEN"; db.commit(); await sio.emit("cell_updated",{"event":"shares_reopened"},room=s.id); return {"status":s.status,"shares":share_breakdown(s,db)}
@app.post("/api/v1/payments/generate-link")
def payment_link(body:LinkIn,db:DBSession=Depends(get_db)):
    s=db.get(Session,body.session_id)
    if not s or s.status!="LOCKED": raise HTTPException(409,"Lock shares before checkout")
    actual=next((x["total_paise"] for x in share_breakdown(s,db)["members"] if x["user_id"]==body.user_id),None)
    if actual is None or actual!=body.exact_share_amount: raise HTTPException(422,"Client amount did not match the locked server-calculated share")
    pid=secrets.token_urlsafe(12); return {"checkout_url":f"https://payments.example.test/phonepe-sim/{pid}?amount={actual}","qr_code_data":f"phonepe-sim://pay/{pid}?paise={actual}","mode":"SIMULATED — no real charge"}
@app.post("/api/v1/payments/webhook")
async def payment_webhook(request:Request):
    # Production must verify provider signature and use an idempotency key before updating payment state.
    return {"accepted":True,"status":"PENDING_SIMULATION","note":"Gateway signatures are not configured in this demo."}
@app.post("/api/v1/loyalty/claim")
def loyalty_claim(body:LoyaltyIn,request:Request,db:DBSession=Depends(get_db)):
    s=db.get(Session,body.session_id)
    if not s: raise HTTPException(404,"Session not found")
    if len(body.location_coords)!=2: raise HTTPException(422,"Location permission is required to validate this visit")
    branch=db.get(Branch,s.branch_id)
    if not branch or branch.latitude is None or branch.longitude is None: raise HTTPException(409,"This outlet needs its location configured before loyalty can be claimed")
    lat,lon=body.location_coords; outlet_lat=branch.latitude; outlet_lon=branch.longitude
    radians=math.pi/180; dlat=(lat-outlet_lat)*radians; dlon=(lon-outlet_lon)*radians
    hav=math.sin(dlat/2)**2+math.cos(outlet_lat*radians)*math.cos(lat*radians)*math.sin(dlon/2)**2; distance=6371000*2*math.atan2(math.sqrt(hav),math.sqrt(1-hav))
    if distance>branch.loyalty_radius_m: raise HTTPException(403,"A stamp can only be claimed near the restaurant")
    created=s.created_at
    if created:
        if created.tzinfo is None: created=created.replace(tzinfo=ZoneInfo("Asia/Kolkata"))
        if (datetime.now(timezone.utc)-created.astimezone(timezone.utc))>timedelta(hours=8): raise HTTPException(403,"The visit is outside the stamp-claim window")
    client_ip=request.client.host if request.client else "unknown"
    identity=hashlib.sha256((body.device_fingerprint+body.phone_number+client_ip).encode()).hexdigest(); device_hash=hashlib.sha256(body.device_fingerprint.encode()).hexdigest(); phone_hash=hashlib.sha256(body.phone_number.encode()).hexdigest(); ip_hash=hashlib.sha256(client_ip.encode()).hexdigest()
    redis_key=f"loyalty:session:{s.id}"
    try: redis_claimed=redis_client.set(redis_key,"pending",nx=True,ex=30)
    except redis.RedisError: redis_claimed=True  # PostgreSQL unique constraint remains the authoritative fallback.
    prior=db.scalar(select(LoyaltyStamp).where(LoyaltyStamp.session_id==s.id))
    if prior or s.stamp_issued or not redis_claimed:
        db.add(LoyaltyAttempt(session_id=s.id,identity_hash=identity,reason="MASTER_BILL_ALREADY_STAMPED")); db.commit()
        raise HTTPException(409,"One loyalty stamp has already been issued for this master bill")
    # Claim is unique by session at the database layer to close concurrent duplicate requests.
    try:
        db.add(LoyaltyStamp(customer_id=identity,session_id=s.id,device_hash=device_hash,phone_hash=phone_hash,ip_hash=ip_hash)); s.stamp_issued=True; db.commit()
        try: redis_client.set(redis_key,"issued",ex=365*24*60*60)
        except redis.RedisError: pass
    except Exception: db.rollback(); raise HTTPException(409,"One loyalty stamp has already been issued for this master bill")
    return {"stamp_issued":True,"session_id":s.id,"message":"One stamp added for this Cell Session."}
@app.get("/api/v1/admin/margins")
def margins(_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    return [{"id":x.id,"name":x.name,"margin_type":x.margin_type,"contribution_paise":x.price_paise-x.cost_paise,"price_paise":x.price_paise,"cost_paise":x.cost_paise,"is_signature":x.is_signature} for x in db.scalars(select(MenuItem)).all()]
@app.get("/api/v1/receipts/{session_id}/{user_id}")
def receipt(session_id:str,user_id:str,db:DBSession=Depends(get_db)):
    s=db.get(Session,session_id)
    if not s: raise HTTPException(404,"Session not found")
    data=share_breakdown(s,db); member=next((x for x in data["members"] if x["user_id"]==user_id),None)
    if not member: raise HTTPException(404,"Diner not found")
    return {"title":"Bail Release Slip","branding":"Flavours of Jail · Cell Block #4","session_id":s.id,"pickup_time":s.pickup_time,"member":member,"master_total_paise":data["master_total_paise"],"reconciles":data["balance_paise"]==0}

@app.get("/dashboard/summary")
def summary(_:Manager=Depends(admin_or_manager),db:DBSession=Depends(get_db)):
    return {"active_branches":len(db.scalars(select(Branch)).all()),"pending_deployments":0,"top_dishes":[{"name":"Cell Block Paneer Pizza","units":328,"revenue_paise":14389200},{"name":"Jailhouse Mocktail Flight","units":286,"revenue_paise":8551400}],"recent_audit":[{"action":x.action,"actor":x.actor_id,"at":x.created_at.isoformat()} for x in db.scalars(select(AuditLog).order_by(desc(AuditLog.created_at)).limit(5)).all()]}

socket_app = socketio.ASGIApp(sio, other_asgi_app=app)
