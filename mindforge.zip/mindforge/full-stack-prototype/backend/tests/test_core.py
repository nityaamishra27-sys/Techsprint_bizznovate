import unittest
from app.core import (
    allocate_pro_rata,
    failed_login_state,
    next_config_version,
    role_allowed,
    split_with_host_remainder,
    tax_from_basis_points,
)

class MoneyAndAccessTests(unittest.TestCase):
    def test_shared_bill_paise_remainder_goes_to_host(self):
        shares = split_with_host_remainder(10001, 4)
        self.assertEqual(shares, [2501, 2500, 2500, 2500])
        self.assertEqual(sum(shares), 10001)

    def test_tax_is_integer_paise_and_pro_rata(self):
        tax = tax_from_basis_points(12345, 500)
        allocation = allocate_pro_rata(tax, {"host": 6000, "guest": 6345}, "host")
        self.assertEqual(tax, 617)
        self.assertEqual(sum(allocation.values()), tax)
        self.assertGreaterEqual(allocation["host"], allocation["guest"]-18)

    def test_staff_is_denied_admin_routes(self):
        self.assertFalse(role_allowed("STAFF", ("SUPER_ADMIN", "MANAGER")))
        self.assertTrue(role_allowed("MANAGER", ("SUPER_ADMIN", "MANAGER")))
        self.assertFalse(role_allowed("UNKNOWN", ("SUPER_ADMIN", "MANAGER")))

    def test_lockout_after_five_failed_attempts(self):
        attempts, locked = failed_login_state(3)
        self.assertEqual(attempts, 4)
        self.assertFalse(locked)
        attempts, locked = failed_login_state(4)
        self.assertEqual(attempts, 0)
        self.assertTrue(locked)

    def test_deploy_and_rollback_always_create_new_version(self):
        self.assertEqual(next_config_version(0), 1)
        self.assertEqual(next_config_version(4), 5)
        with self.assertRaises(ValueError): next_config_version(-1)

if __name__ == "__main__":
    unittest.main()
