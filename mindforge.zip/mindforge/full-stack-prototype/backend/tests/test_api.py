"""HTTP-level smoke coverage. Run with DATABASE_URL pointing at a disposable SQLite file."""
import unittest
from fastapi.testclient import TestClient
from app.main import app
from app.database import SessionLocal
from app.models import Manager
from app.main import pwd

class ProtectedApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.context=TestClient(app)
        cls.client=cls.context.__enter__()
        reply=cls.client.post("/auth/login",json={"manager_id":"MGR-0001","password":"JailDemo!2026"})
        if reply.status_code!=200: raise RuntimeError(reply.text)
        cls.manager_headers={"Authorization":"Bearer "+reply.json()["access_token"]}

    @classmethod
    def tearDownClass(cls): cls.context.__exit__(None,None,None)

    def test_manager_auth_and_staff_rbac(self):
        db=SessionLocal()
        try:
            if not db.query(Manager).filter_by(manager_id="MGR-STAFF-TEST").first():
                db.add(Manager(manager_id="MGR-STAFF-TEST",name="Test Staff",password_hash=pwd.hash("A-test-password-123"),role="STAFF")); db.commit()
        finally: db.close()
        staff_client=TestClient(app)
        denied=staff_client.post("/auth/login",json={"manager_id":"MGR-STAFF-TEST","password":"A-test-password-123"})
        self.assertEqual(denied.status_code,200,denied.text)
        response=staff_client.get("/menu-items",headers={"Authorization":"Bearer "+denied.json()["access_token"]})
        self.assertEqual(response.status_code,403)
        self.assertEqual(self.client.get("/menu-items",headers=self.manager_headers).status_code,200)

    def test_five_bad_passwords_lock_a_provisioned_manager(self):
        db=SessionLocal()
        try:
            if not db.query(Manager).filter_by(manager_id="MGR-LOCK-TEST").first():
                db.add(Manager(manager_id="MGR-LOCK-TEST",name="Lock Test",password_hash=pwd.hash("A-test-password-123"),role="MANAGER")); db.commit()
        finally: db.close()
        client=TestClient(app)
        for _ in range(5): self.assertEqual(client.post("/auth/login",json={"manager_id":"MGR-LOCK-TEST","password":"wrong-password"}).status_code,401)
        self.assertEqual(client.post("/auth/login",json={"manager_id":"MGR-LOCK-TEST","password":"A-test-password-123"}).status_code,401)

    def test_exact_split_lock_and_payment_validation(self):
        created_response=self.client.post("/api/v1/sessions/create",json={"type":"TAKEAWAY_PICKUP","table_id":"CELL-04","pickup_time":"2026-10-23 19:30 Asia/Kolkata","host_name":"Maya"},headers=self.manager_headers)
        self.assertEqual(created_response.status_code,200,created_response.text)
        created=created_response.json()
        session_id=created["session_id"]; member_ids=[created["host_id"]]
        for name in ("Arjun","Nisha","Dev"):
            joined=self.client.post("/api/v1/sessions/join",json={"session_id":session_id,"user_name":name,"device_fingerprint":"test-"+name},headers=self.manager_headers).json(); member_ids.append(joined["user_id"])
        self.client.post("/api/v1/bills/claim-item",json={"session_id":session_id,"item_id":"cheesy-bread","share_type":"SPLIT","member_ids":member_ids},headers=self.manager_headers)
        self.client.post("/api/v1/bills/claim-item",json={"session_id":session_id,"item_id":"pasta","share_type":"FULL","member_ids":[member_ids[1]]},headers=self.manager_headers)
        bill=self.client.get(f"/api/v1/bills/reconcile/{session_id}",headers=self.manager_headers).json()
        self.assertEqual(bill["balance_paise"],0)
        self.assertEqual(sum(x["total_paise"] for x in bill["members"]),bill["master_total_paise"])
        locked=self.client.post(f"/api/v1/bills/lock/{session_id}",headers=self.manager_headers).json()
        amount=next(x["total_paise"] for x in locked["members"] if x["user_id"]==member_ids[0])
        wrong=self.client.post("/api/v1/payments/generate-link",json={"session_id":session_id,"user_id":member_ids[0],"exact_share_amount":amount+1},headers=self.manager_headers)
        self.assertEqual(wrong.status_code,422)
        valid=self.client.post("/api/v1/payments/generate-link",json={"session_id":session_id,"user_id":member_ids[0],"exact_share_amount":amount},headers=self.manager_headers)
        self.assertEqual(valid.status_code,200)
        stamp={"session_id":session_id,"phone_number":"9999991111","device_fingerprint":"test-device","location_coords":[22.7533,75.8937]}
        self.assertEqual(self.client.post("/api/v1/loyalty/claim",json=stamp,headers=self.manager_headers).status_code,200)
        self.assertEqual(self.client.post("/api/v1/loyalty/claim",json=stamp,headers=self.manager_headers).status_code,409)

    def test_publish_is_the_only_public_config(self):
        branch="TST-PUBLIC"
        created=self.client.post("/branches",json={"id":branch,"name":"Test Public Branch","address":"Test address","region":"Central India","manager_id":"MGR-0001"},headers=self.manager_headers)
        self.assertEqual(created.status_code,200,created.text)
        self.assertEqual(self.client.get(f"/public/branches/{branch}/config").status_code,404)
        first=self.client.post(f"/branches/{branch}/deploy",json={"menu_template":"Central India Menu"},headers=self.manager_headers)
        self.assertEqual(first.status_code,200)
        second=self.client.post(f"/branches/{branch}/deploy",json={"menu_template":"Central India Menu"},headers=self.manager_headers)
        self.assertEqual(second.json()["version"],2)
        rollback=self.client.post(f"/branches/{branch}/rollback?version=1",headers=self.manager_headers)
        self.assertEqual(rollback.status_code,200)
        self.assertEqual(rollback.json()["version"],3)
        public=self.client.get(f"/public/branches/{branch}/config")
        self.assertEqual(public.status_code,200)
        self.assertGreaterEqual(len(public.json()["menu"]),20)

if __name__=="__main__": unittest.main()
