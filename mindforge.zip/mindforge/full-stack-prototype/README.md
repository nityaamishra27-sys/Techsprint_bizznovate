# Flavours of Jail — Cell Session & Branch Console

A prototype for the Flavours of Jail restaurant chain: an RBAC-protected branch configuration console plus a branded Cell Session group ordering and bill-splitting demo.

## Run locally

Start Docker Desktop first, wait for it to report that it is running, then double-click `start-prototype.bat` in this folder. It builds and starts the local stack, then opens the prototype in your browser. First build may take a few minutes. To start manually, open a terminal in this folder and run:

```sh
docker compose up --build
```

The local console is at http://localhost:5173 and FastAPI/OpenAPI docs are at http://localhost:8000/docs. To stop the stack, run `docker compose down`. Seeded demo manager: `MGR-0001` / `JailDemo!2026`. Never use demo credentials in a deployed environment. The demo API secret and database settings are in `.env.example`; replace all secrets before deployment.

For UI-only development, run `cd frontend && npm ci && npm run dev`; manager sign-in and API-backed actions need the backend. Some overview charts remain sample prototype data.

## Tests

The backend unit and HTTP tests use `unittest`. With the backend requirements plus `requirements-dev.txt` installed, set `DATABASE_URL` to a disposable SQLite file, set `JWT_SECRET` and `DEMO_MANAGER_PASSWORD`, then run `python -m unittest discover -s tests -v` from `backend/`.

## What is included

- React + TypeScript + Tailwind/Vite responsive console with dashboard, menu, tax, pricing, bestseller, branch deployment, audit and Cell Session views.
- FastAPI REST API with OpenAPI, manager login, hashed passwords, short-lived JWT access tokens, refresh cookie, role checks, lockout, basic rate limits, audit trail and prototype session/menu/bill/loyalty/payment/config APIs.
- PostgreSQL + Redis services and SQLAlchemy data models. Socket.IO server is mounted for session updates.
- Exact paise calculations with deterministic remainder assignment to the host. Payment URLs are simulated and clearly labeled.
- CSV/JSON package export, JSON package import, branch version snapshots and rollback endpoints.
- Real supplied menu and restaurant imagery mapped to dishes and the jail-themed setting.

## Security and prototype boundaries

This is a local demonstration, not a production-ready deployment. It includes a double-submit CSRF token, short-lived access JWTs, manager lockout, Redis rate limiting and a Redis/PostgreSQL one-stamp lock. Before production, configure TLS, a managed secret store, trusted-proxy client IP handling, a real OTP provider if enabled, signed payment-gateway webhooks, and verify each branch-specific geofence location. The refresh cookie uses `SameSite=Strict`; deploy the frontend and API same-site. `STAFF` receives HTTP 403 from protected console APIs. The public branch endpoint returns published snapshots only. The payment webhook is a labeled simulation and does not mark payments paid. The three unresolved business decisions below remain excluded from code.

`npm audit --omit=dev` reports no production dependency vulnerabilities. Full `npm audit` currently reports three moderate issues in Tailwind 3's development-only PostCSS selector parser dependency; upgrading Tailwind to v4 is a breaking change and was not applied.

The briefs left three business decisions unresolved; code deliberately leaves discount/tax ordering, Most Wanted sales period and loyalty wheel unlock eligibility unimplemented pending owner confirmation.

## API areas

`/auth`, `/menu-items`, `/tax-profiles`, `/pricing`, `/bestsellers`, `/branches`, `/audit-logs`, `/public`, `/api/v1/sessions`, `/api/v1/bills`, `/api/v1/payments`, `/api/v1/loyalty`, `/api/v1/admin/margins`.

See the interactive OpenAPI schema at `/docs`.

## Architecture

```mermaid
flowchart LR
  D[Diner PWA / Admin Console<br/>React + TypeScript] -->|REST + Socket.IO| A[FastAPI]
  A --> P[(PostgreSQL<br/>config + sessions + audit)]
  A --> R[(Redis<br/>rate limits + stamp lock)]
  A --> G[PhonePe adapter<br/>simulated in this prototype]
```

All money values crossing persistence/calculation boundaries are integer paise. Postgres stores configuration snapshots per publish version; branches point to the latest published version.
