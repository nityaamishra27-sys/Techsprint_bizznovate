import FingerprintJS from '@fingerprintjs/fingerprintjs';

let visitorIdPromise: Promise<string> | undefined;
export function getDeviceFingerprint() {
  visitorIdPromise ??= FingerprintJS.load().then(agent => agent.get()).then(result => result.visitorId);
  return visitorIdPromise;
}
